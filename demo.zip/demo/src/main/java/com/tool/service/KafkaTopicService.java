package com.tool.service;

import java.util.Collections;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AlterConfigOp;
import org.apache.kafka.clients.admin.ConfigEntry;
import org.apache.kafka.clients.admin.CreateAclsResult;
import org.apache.kafka.clients.admin.DeleteTopicsResult;
import org.apache.kafka.clients.admin.DescribeTopicsResult;
import org.apache.kafka.common.acl.AccessControlEntry;
import org.apache.kafka.common.acl.AclBinding;
import org.apache.kafka.common.acl.AclOperation;
import org.apache.kafka.common.acl.AclPermissionType;
import org.apache.kafka.common.config.ConfigResource;
import org.apache.kafka.common.resource.PatternType;
import org.apache.kafka.common.resource.ResourcePattern;
import org.apache.kafka.common.resource.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.DescribeTopicsResult;
import org.apache.kafka.clients.admin.TopicDescription;
import org.apache.kafka.common.config.ConfigResource;
import org.apache.kafka.clients.admin.DescribeConfigsResult;
import org.apache.kafka.clients.admin.Config;
import org.apache.kafka.common.resource.ResourceType;
@Service
public class KafkaTopicService {

    @Autowired
    private AdminClient adminClient;

    public void deleteTopic(String topicName) throws ExecutionException, InterruptedException {
        DeleteTopicsResult result = adminClient.deleteTopics(Collections.singletonList(topicName));
        result.all().get();  
        System.out.println("Deleted topic: " + topicName);
    }
    
    public void disableTopic(String topicName) throws ExecutionException, InterruptedException {
        ResourcePattern resource = new ResourcePattern(ResourceType.TOPIC, topicName, PatternType.LITERAL);
        AclBinding aclBinding = new AclBinding(
            resource, 
            new AccessControlEntry("User:*", "*", AclOperation.READ, AclPermissionType.DENY)
        );

        CreateAclsResult result = adminClient.createAcls(Collections.singletonList(aclBinding));
        result.all().get();   
        System.out.println("Disabled topic: " + topicName);
    }
    
    public void setRetentionToZero(String topicName) throws ExecutionException, InterruptedException {
        ConfigResource topicResource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
        ConfigEntry retentionEntry = new ConfigEntry("retention.ms", "0");
        AlterConfigOp alterConfigOp = new AlterConfigOp(retentionEntry, AlterConfigOp.OpType.SET);
        adminClient.incrementalAlterConfigs(Collections.singletonMap(topicResource, Collections.singletonList(alterConfigOp))).all().get();
    }
    
    public void throttleProducerBandwidth(String topicName) throws ExecutionException, InterruptedException {
        ConfigResource topicResource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
        ConfigEntry throttleEntry = new ConfigEntry("producer_byte_rate", "1");
        AlterConfigOp alterConfigOp = new AlterConfigOp(throttleEntry, AlterConfigOp.OpType.SET);
        adminClient.incrementalAlterConfigs(Collections.singletonMap(topicResource, Collections.singletonList(alterConfigOp))).all().get();
    }
    
    public void setRetentionTo7Days(String topicName) throws ExecutionException, InterruptedException {
        ConfigResource topicResource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
        ConfigEntry retentionEntry = new ConfigEntry("retention.ms", "604800000");
        AlterConfigOp alterConfigOp = new AlterConfigOp(retentionEntry, AlterConfigOp.OpType.SET);
        adminClient.incrementalAlterConfigs(Collections.singletonMap(topicResource, Collections.singletonList(alterConfigOp))).all().get();
    }
    
    public String getTopicDetails(String topicName) throws ExecutionException, InterruptedException {
        DescribeTopicsResult topicsResult = adminClient.describeTopics(Collections.singletonList(topicName));
        TopicDescription topicDescription = topicsResult.all().get().get(topicName);

        ConfigResource resource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
        DescribeConfigsResult configsResult = adminClient.describeConfigs(Collections.singleton(resource));
        Config config = configsResult.all().get().get(resource);

        StringBuilder details = new StringBuilder();
        details.append("Topic Name: ").append(topicName).append("\n");
        details.append("Partitions: ").append(topicDescription.partitions().size()).append("\n");
        details.append("Replication Factor: ").append(topicDescription.partitions().get(0).replicas().size()).append("\n");
        details.append("Configurations:\n");

        for (ConfigEntry entry : config.entries()) {
            details.append("\t").append(entry.name()).append(": ").append(entry.value()).append("\n");
        }

        return details.toString();
    }
    
    public void setMaxMessageByte(String topicName,String bytes) throws ExecutionException, InterruptedException {
    	//default 1048588
        ConfigResource topicResource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
        ConfigEntry retentionEntry = new ConfigEntry("max.message.bytes",bytes);
        AlterConfigOp alterConfigOp = new AlterConfigOp(retentionEntry, AlterConfigOp.OpType.SET);
        adminClient.incrementalAlterConfigs(Collections.singletonMap(topicResource, Collections.singletonList(alterConfigOp))).all().get();
    }

}

