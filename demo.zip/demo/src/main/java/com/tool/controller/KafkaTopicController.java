package com.tool.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tool.service.KafkaTopicService;

@RestController
@RequestMapping("/kafka")
public class KafkaTopicController {

	@Autowired
	private KafkaTopicService kafkaTopicService;

	@PostMapping("/delete")
	public ResponseEntity<String> deleteTopic(@RequestParam String topicName) {
		try {
			kafkaTopicService.deleteTopic(topicName);
			return ResponseEntity.ok("Topic deleted: " + topicName);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error deleting topic: " + e.getMessage());
		}
	}

	@PostMapping("/disable")
	public ResponseEntity<String> disableTopic(@RequestParam String topicName) {
		try {
			kafkaTopicService.disableTopic(topicName);
			return ResponseEntity.ok("Topic disabled: " + topicName);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error disabling topic: " + e.getMessage());
		}
	}

	@PostMapping("/retentionZero/{topicName}")
	public String retentionZero(@PathVariable String topicName) {
		try {
			kafkaTopicService.setRetentionToZero(topicName);
			return "Topic " + topicName + " has been effectively disabled (retention set to 0).";
		} catch (Exception e) {
			return "Error disabling topic: " + e.getMessage();
		}
	}

	@PostMapping("/throttleProducerBandwidth/{topicName}")
	public String throttleProducerBandwidth(@PathVariable String topicName) {
		try {
			kafkaTopicService.throttleProducerBandwidth(topicName);
			return "Topic " + topicName + " has been effectively disabled (retention set to 0).";
		} catch (Exception e) {
			return "Error disabling topic: " + e.getMessage();
		}
	}

	@PostMapping("/setRetentionTo7Days/{topicName}")
	public String retentionTo7Days(@PathVariable String topicName) {
		try {
			kafkaTopicService.setRetentionTo7Days(topicName);
			return "Topic " + topicName + " has been effectively disabled (retention set to 7 days).";
		} catch (Exception e) {
			return "Error disabling topic: " + e.getMessage();
		}
	}

	@GetMapping("/topic/{topicName}")
	public String getTopicDetails(@PathVariable String topicName) {
		try {
			return kafkaTopicService.getTopicDetails(topicName);
		} catch (ExecutionException | InterruptedException e) {
			return "Error fetching topic details: " + e.getMessage();
		}
	}
	
	@PostMapping("/maxMessageByte/{topicName}/{bytes}")
	public String maxMessageByte(@PathVariable String topicName,@PathVariable String bytes) {
		try {
			kafkaTopicService.setMaxMessageByte(topicName,bytes);
			return "Topic " + topicName + " has been effectively disabled (MaxMessageByte set to)."+bytes;
		} catch (Exception e) {
			return "Error disabling topic: " + e.getMessage();
		}
	}

}
