package com.business.config;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.util.UUID;

public class BatchProducerConfig {
        private static final Config config = ConfigFactory.load();

        public static String getTopicName() {
            return config.getString("balance.topicName");
        }
        public static String getKeySerializer() {
            return config.getString("balance.key.serializer");
        }

        public static String getValueSerializer() {
            return config.getString("balance.value.serializer");
        }

        public static long getBatchSize() {
            return config.getLong("balance.batch.size");
        }

        public static long getLingerMs() {
            return config.getLong("balance.linger.ms");
        }

        public static long getBufferMemory() {
            return config.getLong("balance.buffer.memory");
        }

        public static String getAcks() {
            return config.getString("balance.acks");
        }

        public static String getTransactioId() {
            String transactionalId = "balance-transaction-" + UUID.randomUUID().toString();
            return transactionalId;
        }

    public static String getCompressionType() {
        return config.getString("balance.compression.type");
    }

    public static long getRetry() {
        return config.getLong("balance.retries");
    }
}

