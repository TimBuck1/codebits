package com.business;

import com.business.message.ActionSource;
import com.business.message.Batch;
import com.business.service.BatchKafkaSender;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        BatchKafkaSender batchKafkaService = new BatchKafkaSender();
        Batch batch = new Batch();
        batch.setBatchId("no1");
        batch.setAckReq(true);
        batch.setsId("sid1");
        batch.setActionSource(ActionSource.ADD);
        batchKafkaService.sendMessagesToTopic(List.of(batch));
    }
}