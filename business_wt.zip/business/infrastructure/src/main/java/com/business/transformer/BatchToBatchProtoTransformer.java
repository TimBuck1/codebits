package com.business.transformer;

import com.business.message.Batch;
import com.business.proto.BatchProtos;
public class BatchToBatchProtoTransformer {

    public static BatchProtos.Batch getBatchProtoFromBatch(Batch batch) {
        BatchProtos.Batch.Builder batchBuilder = BatchProtos.Batch.newBuilder();
        batchBuilder.setBatchId("123");
        batchBuilder.setAckReq(true);
        batchBuilder.setSId("sampleId");
        batchBuilder.setActionSource(BatchProtos.Batch.ActionSource.ADD);
        BatchProtos.Batch batchMessage = batchBuilder.build();
        return batchMessage;
    }
}