package com.business.config;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class KafkaConfig {

    private static final Config config = ConfigFactory.load();

    public static String getBootstrapServers() {
        return config.getString("kafka.bootstrap.servers");
    }

    public static String getKeySerializer() {
        return config.getString("kafka.key.serializer");
    }

    public static String getValueSerializer() {
        return config.getString("kafka.value.serializer");
    }

    // Add methods to retrieve other Kafka properties as needed
}
