package com.business.message;

public enum ActionSource {
    ADD, UPDATE, DELETE
}
