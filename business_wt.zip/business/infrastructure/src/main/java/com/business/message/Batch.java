package com.business.message;

import java.io.Serializable;

public class Batch implements Serializable {
    private String batchId;
    private boolean ackReq;
    private String sId;
    private ActionSource actionSource;

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public boolean isAckReq() {
        return ackReq;
    }

    public void setAckReq(boolean ackReq) {
        this.ackReq = ackReq;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public ActionSource getActionSource() {
        return actionSource;
    }

    public void setActionSource(ActionSource actionSource) {
        this.actionSource = actionSource;
    }
}

