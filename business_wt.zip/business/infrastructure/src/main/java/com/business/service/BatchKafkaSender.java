package com.business.service;

import com.business.config.KafkaBatchProducerConfig;
import com.business.message.Batch;
import com.business.proto.BatchProtos;
import com.business.transformer.BatchToBatchProtoTransformer;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.errors.AuthorizationException;
import org.apache.kafka.common.errors.OutOfOrderSequenceException;
import org.apache.kafka.common.errors.ProducerFencedException;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class BatchKafkaSender {
    private final Producer<String, BatchProtos.Batch > kafkaProducer = KafkaBatchProducerConfig.createBatchProducer();
    private final BatchToBatchProtoTransformer transformer = new BatchToBatchProtoTransformer();
    private final  String kafkaTopic;
    public BatchKafkaSender(){
        Config config = ConfigFactory.load();
        kafkaTopic = config.getString("balance.topic.name");
    }

    public void sendMessagesToTopic( List<Batch> messages) {
        if (messages.size() == 0) {
            throw new IllegalArgumentException("Nothing to send to topic.");
        }

        for (int i = 0; i < messages.size(); i++) {
            BatchProtos.Batch item =  BatchToBatchProtoTransformer.getBatchProtoFromBatch(messages.get(i));
            ProducerRecord<String, BatchProtos.Batch > record = new ProducerRecord<>(this.kafkaTopic, item.getBatchId(), item);
            // Send the message to the topic
            kafkaProducer.initTransactions(); // Initialize transactions
            try {
                Future<RecordMetadata> sendResult = kafkaProducer.send(record);
                RecordMetadata metadata = sendResult.get(); // Wait for the send to complete
                kafkaProducer.commitTransaction(); // Commit the transaction
                System.out.printf("Sent message to topic: %s, partition: %d, offset: %d%n",
                        metadata.topic(), metadata.partition(), metadata.offset());
            } catch (InterruptedException | ExecutionException | ProducerFencedException | OutOfOrderSequenceException |
                     AuthorizationException e) {
                System.err.println("Error sending message: " + e.getMessage());
            }
        }
    }

    public void closeProducer() {
        kafkaProducer.close();
    }
}

