package com.business.service;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class KafkaProducerService {

    private final Producer<String, String> kafkaProducer;

    public KafkaProducerService(Producer<String, String> kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    public void sendMessageToTopic(String topic, String key, String message) {
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, message);
        kafkaProducer.send(record, (metadata, exception) -> {
            if (exception == null) {
                System.out.printf("Sent message to topic: %s, partition: %d, offset: %d%n",
                        metadata.topic(), metadata.partition(), metadata.offset());
            } else {
                System.err.println("Error sending message: " + exception.getMessage());
            }
        });
    }

    public void closeProducer() {
        kafkaProducer.close();
    }
}
