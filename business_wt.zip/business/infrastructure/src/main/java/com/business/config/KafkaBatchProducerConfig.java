package com.business.config;

import com.business.proto.BatchProtos;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.util.Properties;

public class KafkaBatchProducerConfig {

    public static Producer<String, BatchProtos.Batch > createBatchProducer() {
        Properties producerProps = new Properties();

        producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KafkaConfig.getBootstrapServers());

        // Add more Kafka producer properties as needed
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, BatchProducerConfig.getKeySerializer());
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, BatchProducerConfig.getValueSerializer());
        // Configure optimization properties
        producerProps.put(ProducerConfig.BATCH_SIZE_CONFIG, BatchProducerConfig.getBatchSize());// 16KB batch size
        producerProps.put(ProducerConfig.LINGER_MS_CONFIG, BatchProducerConfig.getLingerMs()); // 1 ms delay before sending a batch
        producerProps.put(ProducerConfig.BUFFER_MEMORY_CONFIG, BatchProducerConfig.getBufferMemory());
        producerProps.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, BatchProducerConfig.getCompressionType()); // Compression type
        producerProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);

        // Configure exception handling
        producerProps.put(ProducerConfig.ACKS_CONFIG, BatchProducerConfig.getAcks());
        producerProps.put(ProducerConfig.RETRIES_CONFIG, BatchProducerConfig.getRetry()); // Number of retries before giving up


        // Configure transactional producer (optional)
        producerProps.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, BatchProducerConfig.getTransactioId());
        // Create the Kafka producer
        return new KafkaProducer<>(producerProps);
    }
}
