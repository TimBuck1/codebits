package com.business;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@SpringBootApplication
@RestController
public class Main {
    public static void main(String[] args) {/*
        BatchSender producer = new BatchSender();
        Batch batch = new Batch();
        batch.setBatchId("no1");
        batch.setAckReq(true);
        batch.setsId("sid1");
        batch.setActionSource(ActionSource.ADD);
        System.out.println("Hello 2 world!");
        System.out.println("Hello 1 world!");
    //    producer.sendCats(List.of(batch));*/
    }

    @RequestMapping("/")
    public String hello() {
        return "Hello, world!";
    }

}