package com.business.service;

import com.business.message.Batch;
import com.business.proto.BatchProtos;
import com.business.transformer.BatchToBatchProtoTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.DependsOn;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchSender {
    private static final String CAT_TOPIC = "batch-topic"; // Replace with your actual topic name


    @Autowired
    private KafkaTemplate<String, BatchProtos.Batch >  batchKafkaTemplate ;

    @Autowired
    private  BatchToBatchProtoTransformer transformer;


    public void sendCats(List<Batch> batch) {
        for(Batch b : batch){
            BatchProtos.Batch message = transformer.getBatchProtoFromBatch(b);
            batchKafkaTemplate.send(CAT_TOPIC, message);
        }
    }
}
