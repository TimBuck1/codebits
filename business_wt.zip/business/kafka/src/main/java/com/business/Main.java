package com.business;

import com.business.message.ActionSource;
import com.business.message.Batch;
import com.business.service.BatchSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class Main {

    @Autowired
    private BatchSender batchSender;

    public static void main(String[] args) {

        // Start the Spring Boot application and get the application context
        ConfigurableApplicationContext context =   SpringApplication.run(Main.class, args);
        Main main = context.getBean(Main.class);
        main.run();
    }

    public void run() {
        Batch batch = new Batch();
        batch.setBatchId("no1");
        batch.setAckReq(true);
        batch.setsId("sid1");
        batch.setActionSource(ActionSource.ADD);
        batchSender.sendCats(List.of(batch));
    }

}