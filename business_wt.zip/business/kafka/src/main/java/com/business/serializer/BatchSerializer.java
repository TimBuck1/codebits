package com.business.serializer;

import com.business.proto.BatchProtos.Batch;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.errors.SerializationException;

public class BatchSerializer implements Serializer<Batch> {

    @Override
    public byte[] serialize(String topic, Batch data) {
        try {
            try {
                return data.toByteArray(); // Serialize the Batch object to bytes
            } catch (Exception e) {
                throw new SerializationException("Error serializing Batch", e);
            }
        } catch (Exception e) {
            throw new SerializationException("Error serializing Batch", e);
        }
    }

    @Override
    public void close() {
        // Any cleanup logic can go here
    }
}
